import React, { Component } from 'react';

export default class TaskItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      task: this.props.taskItem.task, //while editing we should have previous value of task
      isEditing: false,
    };
  }
  togglePopup() {
    this.setState({
      showPopup: !this.state.showPopup
    });
  }
  setEditingState = (isEditing) => {
    this.setState({ isEditing: isEditing });
  };
  toggleTask = () => {
    this.props.toggleTask(this.props.id);//checks whether task is done or not and pass id of current task to parent component
  };
  deleteTask = () => {
    this.props.deleteTask(this.props.id);
  };
  handleChange = (event) => {
    this.setState({ task: event.target.value }); //typing characters after that we have to submit
  };
  handleSubmit = (event) => {
    event.preventDefault();
    this.props.editTask(this.props.id, this.state.task); //we need to pass index of array as id to taskitem and state is new value for task
    
    this.setState({ isEditing: false }); //after editing we need to update state to false
  };
  render() {
    return (
      <tr>
        {this.state.isEditing ? ( //when it is true is editing
          <>
            <td>
              <div onSubmit={this.handleSubmit}>
                <input value={this.state.task} onChange={this.handleChange} autoFocus />
              </div>
            </td>
            <td>
                
              
            <button className="save" onClick={this.handleSubmit} type="submit">Save</button>{" "}
            
              <button className="back" onClick={() => this.setEditingState(false)} type="button">Back</button>
            </td>
          </>
        ) : (
          <>
            <td className="task" onClick={this.toggleTask}>
             
              <span className={this.props.taskItem.isCompleted}> 
                {this.props.taskItem.task}  
              </span>
            </td>
            <td>
              
              <button className="edit" onClick={() => this.setEditingState(true)}>Edit</button>{" "}
       

              <button className="delete" onClick={this.deleteTask}>Delete</button>
            </td>
            
          </>
        )}
      </tr>
    );
  }
}
