// import React from 'react';

// import CreateTask from './CreateTask';
// import TaskList from './TaskList';
// import "./login.css"


// const tasks = localStorage.getItem('tasks')
//   ? JSON.parse(localStorage.getItem('tasks'))
//   : [];
// export default class Main extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       tasks: tasks,
//     };
//   }
//   createTask = (task) => {
//     if (task.trim() === '') {
//       alert("please Add Task");
//       return;
//     }
    
//     tasks.push({ task, isCompleted: false });
//     this.setState({ tasks: tasks });
//     localStorage.setItem('tasks', JSON.stringify(tasks));
//   };
//   toggleTask = (taskId) => {
//     const taskItem = tasks[taskId];//we need to get access from task item
//     taskItem.isCompleted = !taskItem.isCompleted;//if task is completed is shows true otherwise false like viceversa
//     this.setState({ tasks: tasks });//update state
//     localStorage.setItem('tasks', JSON.stringify(tasks));
//   };
//   deleteTask = (taskId) => {
//     tasks.splice(taskId, 1);
//     this.setState({ tasks: tasks });
//     localStorage.setItem('tasks', JSON.stringify(tasks));
//   };
//   editTask = (taskId, task) => {
//     const taskItem = tasks[taskId];
//     taskItem.task = task;//update task
//     this.setState({ tasks: tasks }); //update state
//     localStorage.setItem('tasks', JSON.stringify(tasks)); 
//   };
//   render() {
//     return (
//       <div class="main">
//         <h1 id='head'>TO DO LIST</h1>
//         <div className="content">
//           <CreateTask createTask={this.createTask} />
//           <br />
//           <TaskList tasks={this.state.tasks} deleteTask={this.deleteTask} editTask={this.editTask} toggleTask={this.toggleTask} />
//         </div>   
//       </div>     
//     );
//   }
// }

import React, {Component} from 'react'
import {Link} from 'react-router-dom'

class Header extends Component
{
    render() {
      return(
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <Link className="navbar-brand" to={'/'}>
              {/* <img src="/logo.jpg" width="30" height="30" className="d-inline-block align-top" alt="Logo"/> */}
                &nbsp; TODO LIST
            </Link>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
          </nav>
        )
    }
}
export default Header